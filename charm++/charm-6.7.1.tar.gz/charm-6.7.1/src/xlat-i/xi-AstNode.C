#include "xi-AstNode.h"
#include "xi-Module.h"
#include "xi-Member.h"


namespace xi {
  namespace details {
    void newLine(XStr &str)
    {
      str << endx;
    }
  }
}
