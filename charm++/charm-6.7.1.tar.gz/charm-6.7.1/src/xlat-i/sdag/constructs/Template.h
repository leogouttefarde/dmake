#ifndef _template_H
#define _template_H

#include "xi-BlockConstruct.h"

namespace xi {

}   // namespace xi

#endif  // ifndef _template_H
