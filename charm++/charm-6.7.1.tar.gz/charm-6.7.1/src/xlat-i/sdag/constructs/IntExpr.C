#include "IntExpr.h"

namespace xi {

IntExprConstruct::IntExprConstruct(const char *ccode)
: SdagConstruct(SINT_EXPR, ccode)
{ }

}   // namespace xi
