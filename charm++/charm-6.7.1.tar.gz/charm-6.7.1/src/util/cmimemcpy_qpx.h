
#ifndef  __CMI_MEMCPY_QPX__
#define  __CMI_MEMCPY_QPX__

#ifdef __cplusplus
extern "C" {
#endif

void CmiMemcpy_qpx (void *dst, const void *src, size_t n);

#ifdef __cplusplus
}
#endif

#endif
