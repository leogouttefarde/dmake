/* Compiles all the .tst files as C++ */
#include "mpi.h"
#include "fem.h"
#include "charm++.h"
#include "ctests.h"

#include "c_tst.h"
#include "test_globals.tst"

#include "test.tst"

