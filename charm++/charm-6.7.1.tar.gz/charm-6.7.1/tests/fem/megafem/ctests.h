/*
FEM Test routines: external interface
*/
#include "charm-api.h"

CDECL void RUN_Test(void);
FDECL void FTN_NAME(RUN_TEST,run_test)(void);

CDECL void RUN_Abort(int v);
FDECL void FTN_NAME(RUN_ABORT,run_abort)(int *v);

