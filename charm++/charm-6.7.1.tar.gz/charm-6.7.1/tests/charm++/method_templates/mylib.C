#include "mylib.h"
#include "mylib.def.h"

int moduleRo;
