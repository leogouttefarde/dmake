#ifndef _MARSHALL_H
#define _MARSHALL_H

#include "charm++.h"
typedef CkMsgQ<CkMarshallMsg> msgQ_t;

#include "marshall.decl.h"
#include "megatest.h"

#endif
