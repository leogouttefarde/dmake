#ifndef _INHERIT_H
#define _INHERIT_H

#include "inherit.decl.h"
#include "megatest.h"

#endif
