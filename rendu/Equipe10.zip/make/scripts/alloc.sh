

# Creates 3 nodes on the current site
oarsub -I -t allow_classic_ssh -l nodes=3

